# -*- coding: utf-8 -*-
#!/usr/bin/env python

"""
pyAppAnnie
"""

__author__ = 'Alexander Tolmach (tolmach@me.com)'
__copyright__ = 'Copyright 2014, Alexander Tolmach'
__license__ = 'MIT'
__version__ = '0.0.1'

from wrapper import AppAnnieAPI as API